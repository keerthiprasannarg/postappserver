### This is a MERN stack application

## Below is the ER Diagram



<img width="822" alt="Screenshot 2024-06-03 at 8 40 48 AM" src="https://github.com/keerthiprasannarg/postapplication/assets/109460040/56f213be-2c9d-4ef5-8fd9-2b0464628b89">
